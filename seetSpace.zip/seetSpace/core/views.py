from urllib import request
from django.shortcuts import render

# Create your views here.

# Create your tests here.
def index(requst):
    return render(request, 'index.html', {})