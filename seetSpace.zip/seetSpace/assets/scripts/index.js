import './helper1'
import './helper2'
import Alpine from 'alpinejs'
import '../styles/index.css'
import './calculator.ts';
import TestImage from '../images/pexels-nurseryart-363766.jpg';

// Add Alpine object to the window scope
window.Alpine = Alpine

// initialize Alpine
Alpine.start()

window.htmx = require('htmx.org');

window.addEventListener('load', () => {
    document.getElementById('message').textContent = 'FROM JAVASCRIPT';
})

window.addEventListener('load', () => {
    const myImg = new Image();
    myImg.src = TestImage;
    myImg.style.width = "200px";
    myImg.style.height = "200px";

    document.body.appendChild(myImg);
})