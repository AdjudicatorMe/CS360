window.addEventListener('load', () =>{
    document.getElementById('message').textContent = 'FROM JAVASCRIPT'
})